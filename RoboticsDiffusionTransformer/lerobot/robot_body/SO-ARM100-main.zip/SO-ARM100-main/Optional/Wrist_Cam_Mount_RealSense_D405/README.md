# Wrist Camera Mount for Intel® RealSense™ D405

<p float="left">
  <img src="../../media/d405_mount.jpg" width="400"/>
  <img src="../../media/d405_mount_sample_observation.jpg" width="400" />
</p>

Use two **DIN 912 M3x6 or M3x8** screws to mount the camera to the wrist.

### Suggested Print Orientation:
<img src="../../media/d405_mount_print_orientation.jpg" width="600" />

